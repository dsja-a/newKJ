## Simple api tavily
## sinc client and async client

### Example Async
from tavily import AsyncTavilyClient
import asyncio
async def main():
    client = AsyncTavilyClient(api_key="your_api_key")
    results = await client.search("Python programming", max_results=3)
    print(results)
asyncio.run(main())

### Example Sync
from tavily import TavilyClient
client = TavilyClient(api_key="your_api_key")
results = client.search("Python programming", max_results=3)
print(results)